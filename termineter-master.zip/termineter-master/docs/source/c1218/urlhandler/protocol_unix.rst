:mod:`c1218.urlhandler.protocol_unix`
=====================================

.. module:: c1218.urlhandler.protocol_unix
   :synopsis:

Classes
-------

.. autoclass:: c1218.urlhandler.protocol_unix.UnixSerial
   :members:
   :special-members: __init__
   :undoc-members:
