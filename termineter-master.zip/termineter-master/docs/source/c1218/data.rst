:mod:`c1218.data`
=================

.. module:: c1218.data
   :synopsis:

Classes
-------

.. autoclass:: c1218.data.C1218Request
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218LogonRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218SecurityRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218LogoffRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218NegotiateRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218WaitRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218IdentRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218TerminateRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218ReadRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218WriteRequest
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.data.C1218Packet
   :members:
   :special-members: __init__
   :undoc-members:
