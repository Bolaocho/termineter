:mod:`c1218.connection`
=======================

.. module:: c1218.connection
   :synopsis:

Classes
-------

.. autoclass:: c1218.connection.Connection
   :members:
   :special-members: __init__
   :undoc-members:

.. autoclass:: c1218.connection.ConnectionBase
   :members:
   :special-members: __init__
   :undoc-members:
