:mod:`c1218.errors`
===================

.. module:: c1218.errors
   :synopsis:

Exceptions
----------

.. autoexception:: c1218.errors.C1218Error

.. autoexception:: c1218.errors.C1218IOError

.. autoexception:: c1218.errors.C1218NegotiateError

.. autoexception:: c1218.errors.C1218ReadTableError

.. autoexception:: c1218.errors.C1218WriteTableError
