:mod:`c1219.errors`
===================

.. module:: c1219.errors
   :synopsis:

Exceptions
----------

.. autoexception:: c1219.errors.C1219ProcedureError

.. autoexception:: c1219.errors.C1219ParseError
