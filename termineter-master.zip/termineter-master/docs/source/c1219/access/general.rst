:mod:`c1219.access.general`
===========================

.. module:: c1219.access.general
   :synopsis:

Classes
-------

.. autoclass:: c1219.access.general.C1219GeneralAccess
   :members:
   :special-members: __init__
   :undoc-members:
