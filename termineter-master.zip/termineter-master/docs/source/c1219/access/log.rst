:mod:`c1219.access.log`
=======================

.. module:: c1219.access.log
   :synopsis:

Classes
-------

.. autoclass:: c1219.access.log.C1219LogAccess
   :members:
   :special-members: __init__
   :undoc-members:
