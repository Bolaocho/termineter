:mod:`c1219.access.security`
============================

.. module:: c1219.access.security
   :synopsis:

Classes
-------

.. autoclass:: c1219.access.security.C1219SecurityAccess
   :members:
   :special-members: __init__
   :undoc-members:
