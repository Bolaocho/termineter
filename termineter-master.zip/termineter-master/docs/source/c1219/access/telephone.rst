:mod:`c1219.access.telephone`
=============================

.. module:: c1219.access.telephone
   :synopsis:

Classes
-------

.. autoclass:: c1219.access.telephone.C1219TelephoneAccess
   :members:
   :special-members: __init__
   :undoc-members:
